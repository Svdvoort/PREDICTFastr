PREDICT;

PREDICT: a Radiomics Extensive Differentiable Interchangable
Classification Toolkit

Quick Start
-----------

PREDICT runs on python version 2.7.

Set-up a virtual environment (`see
here <http://docs.python-guide.org/en/latest/dev/virtualenvs/#virtualenv-burrito>`__).

Then: $ pip install requirements

And you should be got to go!

If not, please open an issue
