#!/usr/bin/env python

# Copyright 2011-2017 Biomedical Imaging Group Rotterdam, Departments of
# Medical Informatics and Radiology, Erasmus MC, Rotterdam, The Netherlands
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import SGDClassifier
import scipy
import numpy as np


def construct_classifier(config, image_features):
    """Interface to create classification

    Different classifications can be created using this common interface

    Args:
        config (dict): Dictionary of the required config settings
        mutation_data (dict): Mutation data that should be classified
        features (pandas dataframe): A pandas dataframe containing the features
         to be used for classification

    Returns:
        Constructed classifier
    """

    if config['Classification']['classifier'] == 'SVM':
        classifier, param_grid = construct_SVM(config)
    elif config['Classification']['classifier'] == 'RF':
        nfeat = len(image_features)
        param_grid = {'n_estimators': scipy.stats.uniform(loc=60, scale=40), 'max_features': scipy.stats.uniform(loc=np.sqrt(nfeat), scale=0.5*np.sqrt(nfeat)), 'min_samples_split': scipy.stats.uniform(loc=5, scale=2)}
        classifier = RandomForestClassifier(verbose=0)
    elif config['Classification']['classifier'] == 'SGD':
        classifier = SGDClassifier(n_iter=config['Classification']['n_epoch'])
        param_grid = {'loss': ['hinge', 'squared_hinge', 'modified_huber'], 'penalty': ['none', 'l2', 'l1']}

    return classifier, param_grid


def construct_SVM(config):
    """
    Constructs a SVM classifier

    Args:
        config (dict): Dictionary of the required config settings
        mutation_data (dict): Mutation data that should be classified
        features (pandas dataframe): A pandas dataframe containing the features
         to be used for classification

    Returns:
        SVM classifier
    """

    clf = SVC(class_weight='balanced', probability=True)
    if config['Classification']['Kernel'] == "polynomial":
        param_grid = {'kernel': ['poly'], 'C': scipy.stats.uniform(loc=0.5e8, scale=0.5e8), 'degree': scipy.stats.uniform(loc=3.5, scale=1.5), 'coef0': scipy.stats.uniform(loc=0.5, scale = 0.5)}

    elif config['Classification']['Kernel'] == "linear":
        param_grid = {'kernel': ['linear'], 'C': scipy.stats.uniform(loc=0.5e8, scale=0.5e8), 'degree': scipy.stats.uniform(loc=3.5, scale=1.5), 'coef0': scipy.stats.uniform(loc=0.5, scale=0.5)}

    elif config['Classification']['Kernel'] == "rbf":
        param_grid = {'kernel': ['rbf'], 'gamma':  scipy.stats.uniform(loc=0.5e-3, scale=0.5e-3), 'nu': scipy.stats.uniform(loc=0.5, scale=0.5)}

    return clf, param_grid
